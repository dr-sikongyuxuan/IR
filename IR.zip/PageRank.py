import numpy as np
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize 

corpus_pre = [
    "Gandalf is a fictional character in Tolkien's The Lord of the Rings",
    "Frodo is the main character in The Lord of the Rings",
    "Ian McKellen interpreted Gandalf in Peter Jackson's movies",
    "Elijah Wood was cast as Frodo Baggins in Jackson's adaptation",
    "The Lord of the Rings is an epic fantasy novel by J. R. R. Tolkien"]

# corpus_pre = open("D:/college lessons/信息检索/corpus.txt",'r',encoding='utf-8').readlines()

def create_data(N, alpha=0.5): # random > alpha, then here is a edge.
    G = np.zeros((N, N))
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            if random.random() < alpha:
                G[i][j] = 1
    return G

def GtoM(G, N):
    M = np.zeros((N, N))
    for i in range(N):
        D_i = sum(G[i])
        if D_i == 0:
            continue
        for j in range(N):
            M[j][i] = G[i][j] / D_i # watch out! M_j_i instead of M_i_j
    return M

def PageRank(M, N, T=300, eps=1e-6):
    R = np.ones(N) / N
    for time in range(T):
        R_new = np.dot(M, R)
        if np.linalg.norm(R_new - R) < eps:
            break
        R = R_new.copy()
    return R_new


def Rand_surfer(M, N, T=300, eps=1e-6, beta=0.8):
    R = np.ones(N) / N
    teleport = np.ones(N) / N
    for time in range(T):
        R_new = beta * np.dot(M, R) + (1-beta)*teleport
        if np.linalg.norm(R_new - R) < eps:
            break
        R = R_new.copy()
    return R_new

def cosine_similarity(x,y):
    sum = 0
    d1 = 0
    d2 = 0
    for i in range(len(x)):
        sum += (x[i] * y[i])
        d1 += (x[i] * x[i])
        d2 += (y[i] * y[i])
    d1 = np.sqrt(d1)
    d2 = np.sqrt(d2)
    d1 = d1 * d2
    if d1 == 0 :
        return 0
    else:
        return sum / d1 

def generate_corpus():
    stop_words = set(stopwords.words('english'))  # 加载停用词
    corpus = [] # 去除停用词
    for  i in range(len(corpus_pre)):
        corpus_tokens = word_tokenize(corpus_pre[i])
        filtered_sentence = [w for w in corpus_tokens if w not in stop_words]
        filtered_sentence = " ".join(filtered_sentence)
        corpus.append(filtered_sentence)
    return corpus 

def get_keywords(corpus):
    tfidf = TfidfVectorizer() 
    result = tfidf.fit_transform(corpus).toarray() #生成TF-IDF向量
    word = tfidf.get_feature_names() # 统计关键词

    key_words = {}
    # 对比第i类文本的词语tf-idf权重
    for i in range(len(result)):
        for j in range(len(word)):
            if result[i][j] > 0 :
                key_words[word[j]] = result[i][j]
    key_words = sorted(key_words.items(), key = lambda e:e[1],reverse = True)
    return key_words

def get_result(num,key_words):
    words_final = []
    for i in range(num):
        words_final.append(key_words[i])

    vsm = []  # 构造语料库的关键词向量
    for j in range(len(corpus)):
        t = []
        for i in range(len(words_final)):
            if corpus[j].find(words_final[i][0]) != -1:
                t.append(words_final[i][1])
            else:
                t.append(0)
        vsm.append(t)

    q = [] # 构造查询的关键词向量
    for i in range(len(words_final)):
        if query.find(words_final[i][0]) != -1:
            q.append(words_final[i][1])
        else:
            q.append(0)

    results = []
    #查找相似度并排序
    for i in range(len(vsm)):
        results.append(cosine_similarity(q,vsm[i]))
    return results

def find_term(query,corpus):
    query  = query.split()
    terms = []
    for i in range(len(corpus)):
        terms.append(0x3f3f3f3f)

    for i in range(len(corpus)):
        corpus[i] = corpus[i].split()
        k = 0
        start = 0
        end = 0x3f3f3f3f
        for j in range(len(corpus[i])):
            while corpus[i][j] == query[k]:
                if k == 0:
                    start = j
                if k + 1 == len(query):
                   end = j
                   break
                k += 1
        if end < 0x3f3f3f3f:
            terms[i] = end - start + 1
    print(terms)
    return terms

if __name__ == "__main__":
    num = 5
    G = create_data(num)
    print(G)
    query = "main character"
    corpus = generate_corpus()
    keywords = get_keywords(corpus)
    value1 = get_result(20,keywords)
    print('value1: ',value1)  #查询结果

    terms =  find_term(query,corpus)

    M = GtoM(G, num)
    value2 = PageRank(M, num, T = 100)  #计算PR值
    print('value2: ',value2)
    result = []
    sum = 0
    for i in range(len(value1)):
        result.append(value1[i] + value2[i])
        sum += result[i]
    final = {}
    for i in range(len(value1)):
        result[i] = result[i] / sum
        final[i] = result[i]
    
    final2 = {}
    for i in range(len(value1)):
        if value1[i] + value2[i] == 0 :
            final2[i] = 0
        else: 
            final2[i] = (2 * value1[i] * value2[i] / (value1[i] + value2[i]))
    
    final = sorted(final.items(), key = lambda e:e[1],reverse = True)
    final2 = sorted(final2.items(), key = lambda e:e[1],reverse = True)
    print("--------------Retrival Results --------")
    for i in range(len(final)):
        t = final[i]
        print(corpus_pre[t[0]])
    print("")
    print("--------------Retrival Results2 --------")
    for i in range(len(final2)):
        t = final2[i]
        print(corpus_pre[t[0]])