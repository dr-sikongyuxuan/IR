from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize 
import numpy as np

def cosine_similarity(x,y):
    sum = 0
    d1 = 0
    d2 = 0
    for i in range(len(x)):
        sum += (x[i] * y[i])
        d1 += (x[i] * x[i])
        d2 += (y[i] * y[i])
    d1 = np.sqrt(d1)
    d2 = np.sqrt(d2)
    d1 = d1 * d2
    if d1 == 0 :
        return 0
    else:
        return sum / d1 

query = "how can one wait to split an work page with c # or other service"
stop_words = set(stopwords.words('english'))  # 加载停用词

# corpus_pre = [
#     "Gandalf is a fictional character in Tolkien's The Lord of the Rings",
#     "Frodo is the main character in The Lord of the Rings",
#     "Ian McKellen interpreted Gandalf in Peter Jackson's movies",
#     "Elijah Wood was cast as Frodo Baggins in Jackson's adaptation",
#     "The Lord of the Rings is an epic fantasy novel by J. R. R. Tolkien"]
corpus_pre = open("D:/college lessons/信息检索/corpus.txt",'r',encoding='utf-8').readlines()[:100]

corpus = [] # 去除停用词
for  i in range(len(corpus_pre)):
    corpus_tokens = word_tokenize(corpus_pre[i])
    filtered_sentence = [w for w in corpus_tokens if w not in stop_words]
    filtered_sentence = " ".join(filtered_sentence)
    corpus.append(filtered_sentence) 
# print(corpus)

tfidf = TfidfVectorizer() 
result = tfidf.fit_transform(corpus).toarray() #生成TF-IDF向量
word = tfidf.get_feature_names() # 统计关键词

key_words = {}
# 对比第i类文本的词语tf-idf权重
for i in range(len(result)):
    for j in range(len(word)):
        if result[i][j] > 0 :
            key_words[word[j]] = result[i][j]
key_words = sorted(key_words.items(), key = lambda e:e[1],reverse = True)

# print(key_words[:20])

num = 20
words_final = []
for i in range(num):
    words_final.append(key_words[i])

vsm = []  # 构造语料库的关键词向量
for j in range(len(corpus)):
    t = []
    for i in range(len(words_final)):
        if corpus[j].find(words_final[i][0]) != -1:
            t.append(words_final[i][1])
        else:
            t.append(0)
    vsm.append(t)


q = [] # 构造查询的关键词向量
for i in range(len(words_final)):
    if query.find(words_final[i][0]) != -1:
        q.append(words_final[i][1])
    else:
        q.append(0)

# print(q)
results = {}
#查找相似度并排序
for i in range(len(vsm)):
    results[i + 1] = cosine_similarity(q,vsm[i])
results = sorted(results.items(), key = lambda e:e[1],reverse = True)
print("--------------Retrival Results --------")
for i in range(len(results)):
    if i >= 5:
        break
    t = results[i]
    print("%s%f" %(corpus_pre[t[0]],t[1]))
