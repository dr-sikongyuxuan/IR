from eldar import Query

documents = open("D:/college lessons/信息检索/corpus.txt",'r',encoding='utf-8').readlines()
docu_set = {}
for i in range(len(documents)):
    docu_set[i + 1] = documents[i]
# docu_set={'d1':'i love shanghai',
#           'd2':'i am from shanghai now i study in tongji university',
#           'd3':'i am from lanzhou now i study in lanzhou university of science  and  technolgy',}


all_words=[]  #存储所有词
for i in docu_set.values():
#    cut = jieba.cut(i)
    cut=i.split()
    all_words.extend(cut)
    
set_all_words=set(all_words)  #去重

# print(set_all_words)

cnt = 0

invert_index=dict()
for b in set_all_words:
    temp=[]
    for j in docu_set.keys():
        
        # if cnt == 0: 
        #     print("docu_set[j]: ",docu_set[j])
        field = docu_set[j]
        
        split_field = field.split()
        
        if b in split_field:
            temp.append(j)
        # cnt = 1
    invert_index[b] = temp
    
print("--------------Retrival Results --------")
# print('how: ',invert_index['how'])
# print('you: ',invert_index['you'])
print('print: ',invert_index['print'])