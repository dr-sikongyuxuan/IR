from eldar import Query

#这个算是我今天用的一个伪代码，文件路径，打开模式，编码方式
documents = open("D:/college lessons/信息检索/corpus.txt",'r',encoding='utf-8').readlines()

# documents = [
#     "Gandalf is a fictional character in Tolkien's The Lord of the Rings",
#     "Frodo is the main character in The Lord of the Rings",
#     "Ian McKellen interpreted Gandalf in Peter Jackson's movies",
#     "Elijah Wood was cast as Frodo Baggins in Jackson's adaptation",
#     "The Lord of the Rings is an epic fantasy novel by J. R. R. Tolkien"]

eldar = Query('("sql") AND NOT ("aggregate" OR "thread")')
result = eldar.filter(documents)

print("--------------Retrival Results --------")
for i in range(len(result)):
    print(result[i])


# print(eldar(documents[0]))